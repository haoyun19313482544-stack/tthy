# ForgeTest Android APK 工程

## 零环境一键云打包 APK（推荐，2 分钟拿到安装包）
1. 在 GitHub 新建一个仓库（公开或私有均可）。
2. 将本压缩包解压后的全部文件上传到该仓库根目录（确保包含 `.github/workflows/build-apk.yml`）。
3. 打开仓库顶部的 **Actions** 页面，等待 `Build ForgeTest Android APK` 自动运行完成（约 2 分钟）。
4. 点进该次构建，在底部 **Artifacts** 下载 `ForgeTest-Android-APK`，解压即得可直接安装到安卓手机的 `app-debug.apk`。

## 本地打包（如已安装 Android Studio）
用 Android Studio 打开本目录，点击菜单 `Build -> Build Bundle(s) / APK(s) -> Build APK(s)` 即可。

## 原生增强特性
- 内置 Kotlin `NativeBridge` 异步 HTTP 代理，彻底绕过浏览器 CORS 跨域限制，支持任意第三方中转站及局域网 Ollama。
- 支持安卓原生文件选择器导入 `.txt / .md / .json` 系统提示词。
