package com.forge.chat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Map<String, HttpURLConnection> conns = new ConcurrentHashMap<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private static final int REQ_SAVE = 1001;
    private static final int REQ_PICK = 1002;
    private ValueCallback<Uri[]> filePathCallback = null;
    private String pendingSaveId = null;
    private String pendingSaveName = null;
    private String pendingSaveContent = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFFFFFFFF);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        try {
            s.setAllowUniversalAccessFromFileURLs(true);
        } catch (Throwable ignored) {
        }

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                }
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(intent, "选择文件"), REQ_PICK);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        String probe =
            "(function(){try{" +
            "var d=document.getElementById('drawerMask');" +
            "if(d&&d.className.indexOf('show')>=0){d.className='mask';return true}" +
            "var ms=document.querySelectorAll('.modal-mask.show');" +
            "if(ms.length){ms[0].className='modal-mask';return true}" +
            "return false}catch(e){return false}})()";
        web.evaluateJavascript(probe, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{ data.getData() };
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }

        if (requestCode != REQ_SAVE) return;

        String rid = pendingSaveId;
        String name = pendingSaveName;
        String content = pendingSaveContent;
        pendingSaveId = null;
        pendingSaveName = null;
        pendingSaveContent = null;
        if (rid == null) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            emit("window.__onFileResult(" + jsStr(rid) + ",false,'用户取消了保存')");
            return;
        }

        Uri uri = data.getData();
        OutputStream os = null;
        try {
            os = getContentResolver().openOutputStream(uri);
            os.write((content == null ? "" : content).getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            os = null;
            emit("window.__onFileResult(" + jsStr(rid) + ",true," +
                 jsStr("已保存：" + (name == null ? "" : name)) + ")");
        } catch (Exception e) {
            emit("window.__onFileResult(" + jsStr(rid) + ",false," + jsStr(String.valueOf(e)) + ")");
        } finally {
            if (os != null) {
                try { os.close(); } catch (Throwable ignored) {}
            }
        }
    }

    private static String mimeOf(String fn) {
        String n = fn == null ? "" : fn.toLowerCase();
        if (n.endsWith(".md") || n.endsWith(".txt") || n.endsWith(".log")) return "text/plain";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".xml")) return "text/xml";
        if (n.endsWith(".py")) return "text/x-python";
        if (n.endsWith(".js")) return "application/javascript";
        if (n.endsWith(".pdf")) return "application/pdf";
        return "application/octet-stream";
    }

    private void emit(final String js) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                try {
                    web.evaluateJavascript(js, null);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    private static String jsStr(String v) {
        if (v == null) return "''";
        StringBuilder sb = new StringBuilder(v.length() + 24);
        sb.append('\'');
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '\'': sb.append("\\'"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case 0x2028: sb.append("\\u2028"); break;
                case 0x2029: sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('\'');
        return sb.toString();
    }

    private static String readAll(InputStream in, int cap) {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            char[] buf = new char[4096];
            int n;
            while ((n = br.read(buf)) > 0) {
                sb.append(buf, 0, n);
                if (sb.length() > cap) break;
            }
            br.close();
        } catch (Exception ignored) {
        }
        return sb.toString();
    }

    private static void applyHeaders(HttpURLConnection conn, String headersJson) {
        try {
            if (headersJson != null && headersJson.trim().length() > 2) {
                JSONObject h = new JSONObject(headersJson);
                Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    conn.setRequestProperty(k, h.getString(k));
                }
            }
        } catch (Exception ignored) {
        }
    }

    public class Bridge {

        @JavascriptInterface
        public void copyToClipboard(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("ForgeTest", text == null ? "" : text));
                    } catch (Throwable ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void saveFileAsync(final String reqId, final String filename, final String content) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingSaveId = reqId;
                        pendingSaveName = filename == null ? "file.txt" : filename;
                        pendingSaveContent = content == null ? "" : content;

                        Intent it = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        it.addCategory(Intent.CATEGORY_OPENABLE);
                        it.setType(mimeOf(pendingSaveName));
                        it.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
                        startActivityForResult(it, REQ_SAVE);
                    } catch (Exception e) {
                        pendingSaveId = null;
                        emit("window.__onFileResult(" + jsStr(reqId) + ",false," + jsStr(String.valueOf(e)) + ")");
                    }
                }
            });
        }

        @JavascriptInterface
        public void httpGetAsync(final String reqId, final String url, final String headersJson) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection conn = null;
                    try {
                        conn = (HttpURLConnection) new URL(url).openConnection();
                        conn.setRequestMethod("GET");
                        conn.setConnectTimeout(20000);
                        conn.setReadTimeout(60000);
                        conn.setRequestProperty("Accept", "text/html,application/json,*/*");
                        applyHeaders(conn, headersJson);

                        conns.put(reqId, conn);
                        int code = conn.getResponseCode();
                        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                        String body = readAll(is, 400000);
                        emit("window.__onAndroidHttpResponse(" + jsStr(reqId) + "," + code + "," + jsStr(body) + ",null)");
                    } catch (Exception e) {
                        emit("window.__onAndroidHttpResponse(" + jsStr(reqId) + ",0,''," + jsStr(String.valueOf(e)) + ")");
                    } finally {
                        conns.remove(reqId);
                        if (conn != null) {
                            try { conn.disconnect(); } catch (Throwable ignored) {}
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void httpStreamPostAsync(final String reqId, final String url,
                                        final String headersJson, final String bodyJson) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection conn = null;
                    try {
                        conn = (HttpURLConnection) new URL(url).openConnection();
                        conn.setRequestMethod("POST");
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(300000);
                        conn.setDoInput(true);
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                        conn.setRequestProperty("Accept", "text/event-stream");
                        applyHeaders(conn, headersJson);

                        if (bodyJson != null && bodyJson.length() > 0) {
                            conn.setDoOutput(true);
                            byte[] payload = bodyJson.getBytes(StandardCharsets.UTF_8);
                            conn.setFixedLengthStreamingMode(payload.length);
                            OutputStream os = conn.getOutputStream();
                            os.write(payload);
                            os.flush();
                            os.close();
                        }

                        conns.put(reqId, conn);
                        int code = conn.getResponseCode();

                        if (code < 200 || code >= 300) {
                            String err = readAll(conn.getErrorStream(), 4000);
                            emit("window.__onAndroidStreamDone(" + jsStr(reqId) + "," + code + "," + jsStr("HTTP " + code + " " + err) + ")");
                            return;
                        }

                        BufferedReader br = new BufferedReader(
                                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                        String line;
                        int pending = 0;
                        StringBuilder batch = new StringBuilder(8192);

                        while ((line = br.readLine()) != null) {
                            if (line.length() == 0) continue;
                            batch.append("window.__onAndroidStreamChunk(")
                                 .append(jsStr(reqId)).append(",")
                                 .append(jsStr(line)).append(");");
                            pending++;
                            if (pending >= 20) {
                                emit(batch.toString());
                                batch.setLength(0);
                                pending = 0;
                            }
                        }
                        if (batch.length() > 0) emit(batch.toString());
                        br.close();
                        emit("window.__onAndroidStreamDone(" + jsStr(reqId) + "," + code + ",null)");

                    } catch (Exception e) {
                        emit("window.__onAndroidStreamDone(" + jsStr(reqId) + ",0," + jsStr(String.valueOf(e)) + ")");
                    } finally {
                        conns.remove(reqId);
                        if (conn != null) {
                            try { conn.disconnect(); } catch (Throwable ignored) {}
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void abortStream(String reqId) {
            HttpURLConnection c = conns.get(reqId);
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) {}
                conns.remove(reqId);
            }
        }

        @JavascriptInterface
        public String platform() {
            return "android";
        }
    }
}
