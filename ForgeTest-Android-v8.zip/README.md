# ForgeTest v8 · 安卓版（补强版）

界面沿用原版，一行未动。改动全在脚本内部和 Java 桥。

## 打包

1. 推到 GitHub
2. Actions 等变绿
3. Artifacts 下载 `ForgeTest-Android-APK`
4. 解压装 `app-debug.apk`

## 这一版补了什么

**1. 修了「思考吃光额度」被误判成拒绝**
flash / v4-pro 这类思考模型会先花几百 token 想。额度不够时正文 0 字、finish=length。
旧版把这个当成"被拒绝"，于是五套说法全"失败"——其实一次真正的拒绝都没发生。
现在分开处理：额度不够 → 同一套把 max_tokens 加到 3 倍重试，不算换说法。

**2. 工具调用（原来一个都没有）**

| 工具 | 作用 |
|---|---|
| fetch_url | 抓任意网址，把网页正文捞回来 |
| get_time | 当前日期时间 |
| save_note / read_note / list_notes | 本机笔记，跨对话留存 |
| copy_text | 直接写进剪贴板 |
| save_file | 存成手机文件，弹系统保存框，**自己选文件夹和文件名** |

模型自己决定什么时候用。状态栏会显示「调用工具：xxx」。

**3. 记住哪套说法过了**
同一个问题再问一次，直接从那套开始试，不从头轮。

**4. 强制先动手，不许只给方案**
底盘里加了硬条款：能做就直接调工具，把真实结果拿回来再说。
禁止「要我把…跑一遍吗」「说一声我就…」。
实测：同一句需求，加之前它给你讲三段方案；加之后它自己抓了 certspotter、探了 7 个端点、自己出结论。

**5. 早断阈值 12~360 → 6~420**
中文拒答常常 6-10 字就开场，旧下限会漏判。

**6. 桥接对齐**
原版调 `AndroidBridge.httpStreamPostAsync / httpGetAsync / copyToClipboard`，
Java 侧按这套名字实现，带真流式、错误回传、停止时真掐连接。

## 文件

```
app/src/main/assets/index.html          界面 + 引擎（原版 UI，脚本补强）
app/src/main/java/.../MainActivity.java   WebView 壳 + AndroidBridge
ForgeTest-Mobile-v8.html                 同一个界面的浏览器预览版
```
