package com.forgetest.termux

import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val outFile = File(filesDir, "forge_android_single.py")
        assets.open("forge_android_single.py").use { inp ->
            outFile.outputStream().use { out -> inp.copyTo(out) }
        }
        val tv = TextView(this).apply {
            setPadding(40, 60, 40, 60)
            textSize = 14f
            text = "ForgeTermux v7 单文件已释放至本机路径：\n\n" +
                outFile.absolutePath + "\n\n" +
                "可在 Termux / Pydroid 3 中直接运行该脚本。"
        }
        setContentView(ScrollView(this).apply { addView(tv) })
    }
}
