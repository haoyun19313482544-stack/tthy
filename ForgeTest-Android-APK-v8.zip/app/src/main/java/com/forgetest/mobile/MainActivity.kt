package com.forgetest.mobile

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val ioPool = Executors.newCachedThreadPool()

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.databaseEnabled = true

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    filePickerLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        webView.addJavascriptInterface(NativeBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun httpGetAsync(reqId: String, urlStr: String, headersJson: String) {
            ioPool.execute {
                var status = 0
                var respBody = ""
                var errMsg: String? = null
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 20000
                        readTimeout = 30000
                        val hdrs = JSONObject(headersJson)
                        val keys = hdrs.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            setRequestProperty(k, hdrs.optString(k))
                        }
                    }
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    respBody = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    errMsg = "${e.javaClass.simpleName}: ${e.message}"
                } finally {
                    conn?.disconnect()
                }

                val js = "window.__onAndroidHttpResponse(" +
                    "${JSONObject.quote(reqId)}, $status, ${JSONObject.quote(respBody)}, " +
                    "${if (errMsg == null) "null" else JSONObject.quote(errMsg)});"
                webView.post { webView.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface
        fun httpStreamPostAsync(reqId: String, urlStr: String, headersJson: String, bodyStr: String) {
            ioPool.execute {
                var status = 0
                var errMsg: String? = null
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 30000
                        readTimeout = 180000
                        doOutput = true
                        val hdrs = JSONObject(headersJson)
                        val keys = hdrs.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            setRequestProperty(k, hdrs.optString(k))
                        }
                    }
                    conn.outputStream.use { os ->
                        os.write(bodyStr.toByteArray(Charsets.UTF_8))
                    }
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    if (stream != null) {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                            var line: String?
                            while (reader.readLine().also { line = it } != null) {
                                val curLine = line ?: continue
                                val chunkJs = "window.__onAndroidStreamChunk(${JSONObject.quote(reqId)}, ${JSONObject.quote(curLine)});"
                                webView.post { webView.evaluateJavascript(chunkJs, null) }
                            }
                        }
                    }
                } catch (e: Exception) {
                    errMsg = "${e.javaClass.simpleName}: ${e.message}"
                } finally {
                    conn?.disconnect()
                }

                val doneJs = "window.__onAndroidStreamDone(" +
                    "${JSONObject.quote(reqId)}, $status, " +
                    "${if (errMsg == null) "null" else JSONObject.quote(errMsg)});"
                webView.post { webView.evaluateJavascript(doneJs, null) }
            }
        }

        @JavascriptInterface
        fun copyToClipboard(text: String) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ForgeTest", text))
        }

        @JavascriptInterface
        fun saveTextFile(filename: String, content: String): String {
            return try {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
                val out = File(dir, filename)
                out.writeText(content, Charsets.UTF_8)
                "已保存至：${out.absolutePath}"
            } catch (e: Exception) {
                "保存失败：${e.message}"
            }
        }
    }

    override fun onDestroy() {
        ioPool.shutdownNow()
        super.onDestroy()
    }
}
